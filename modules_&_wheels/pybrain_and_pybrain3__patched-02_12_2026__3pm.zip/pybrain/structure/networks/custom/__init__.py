from .capturegame import CaptureGameNetwork
