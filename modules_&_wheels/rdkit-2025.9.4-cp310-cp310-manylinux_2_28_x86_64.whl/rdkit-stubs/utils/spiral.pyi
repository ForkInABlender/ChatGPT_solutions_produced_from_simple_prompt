from __future__ import annotations
import math as math
import numpy
from numpy import __array_namespace_info__
import numpy._pytesttester
from numpy import all
from numpy import allclose
from numpy import amax
from numpy import amin
from numpy import angle
from numpy import any
from numpy import append
from numpy import apply_along_axis
from numpy import apply_over_axes
from numpy import arange
from numpy import argmax
from numpy import argmin
from numpy import argpartition
from numpy import argsort
from numpy import argwhere
from numpy import around
from numpy import array
from numpy import array2string
from numpy import array_equal
from numpy import array_equiv
from numpy import array_repr
from numpy import array_split
from numpy import array_str
from numpy import asanyarray
from numpy import asarray
from numpy import asarray_chkfinite
from numpy import ascontiguousarray
from numpy import asfortranarray
from numpy import asmatrix
from numpy import astype
from numpy import atleast_1d
from numpy import atleast_2d
from numpy import atleast_3d
from numpy import average
from numpy import bartlett
from numpy import base_repr
from numpy import binary_repr
from numpy import bincount
from numpy import blackman
from numpy import block
from numpy import bmat
from numpy import bool as bool_
from numpy import bool
from numpy import broadcast
from numpy import broadcast_arrays
from numpy import broadcast_shapes
from numpy import broadcast_to
from numpy import busday_count
from numpy import busday_offset
from numpy import busdaycalendar
from numpy import bytes_
from numpy import can_cast
from numpy import char
from numpy import character
from numpy import choose
from numpy import clip
from numpy import clongdouble
from numpy import clongdouble as complex256
from numpy import column_stack
from numpy import common_type
from numpy import complex128
from numpy import complex128 as cdouble
from numpy import complex64 as csingle
from numpy import complex64
from numpy import complexfloating
from numpy import compress
from numpy import concatenate as concat
from numpy import concatenate
from numpy import convolve
from numpy import copy
from numpy import copyto
from numpy import core
from numpy import corrcoef
from numpy import correlate
from numpy import count_nonzero
from numpy import cov
from numpy import cross
from numpy import ctypeslib
from numpy import cumprod
from numpy import cumsum
from numpy import cumulative_prod
from numpy import cumulative_sum
from numpy import datetime64
from numpy import datetime_as_string
from numpy import datetime_data
from numpy import delete
from numpy import diag
from numpy import diag_indices
from numpy import diag_indices_from
from numpy import diagflat
from numpy import diagonal
from numpy import diff
from numpy import digitize
from numpy import dot
from numpy import dsplit
from numpy import dstack
from numpy import dtype
from numpy import dtypes
from numpy import ediff1d
from numpy import einsum
from numpy import einsum_path
from numpy import empty
from numpy import empty_like
from numpy import errstate
from numpy import exceptions
from numpy import expand_dims
from numpy import extract
from numpy import eye
from numpy import f2py
from numpy import fft
from numpy import fill_diagonal
from numpy import finfo
from numpy import fix
from numpy import flatiter
from numpy import flatnonzero
from numpy import flexible
from numpy import flip
from numpy import fliplr
from numpy import flipud
from numpy import float16 as half
from numpy import float16
from numpy import float32
from numpy import float32 as single
from numpy import float64 as double
from numpy import float64
from numpy import floating
from numpy import format_float_positional
from numpy import format_float_scientific
from numpy import from_dlpack
from numpy import frombuffer
from numpy import fromfile
from numpy import fromfunction
from numpy import fromiter
from numpy import frompyfunc
from numpy import fromregex
from numpy import fromstring
from numpy import full
from numpy import full_like
from numpy import generic
from numpy import genfromtxt
from numpy import geomspace
from numpy import get_include
from numpy import get_printoptions
from numpy import getbufsize
from numpy import geterr
from numpy import geterrcall
from numpy import gradient
from numpy import hamming
from numpy import hanning
from numpy import histogram
from numpy import histogram2d
from numpy import histogram_bin_edges
from numpy import histogramdd
from numpy import hsplit
from numpy import hstack
from numpy import i0
from numpy import identity
from numpy import iinfo
from numpy import imag
from numpy import in1d
from numpy import indices
from numpy import inexact
from numpy import info
from numpy import inner
from numpy import insert
from numpy import int16
from numpy import int16 as short
from numpy import int32 as intc
from numpy import int32
from numpy import int64
from numpy import int64 as long
from numpy import int64 as int_
from numpy import int64 as intp
from numpy import int8
from numpy import int8 as byte
from numpy import integer
from numpy import interp
from numpy import intersect1d
from numpy import is_busday
from numpy import isclose
from numpy import iscomplex
from numpy import iscomplexobj
from numpy import isdtype
from numpy import isfortran
from numpy import isin
from numpy import isneginf
from numpy import isposinf
from numpy import isreal
from numpy import isrealobj
from numpy import isscalar
from numpy import issubdtype
from numpy import iterable
from numpy import ix_
from numpy import kaiser
from numpy import kron
from numpy import lexsort
from numpy import lib
import numpy.lib._index_tricks_impl
from numpy.lib import scimath as emath
from numpy import linalg
from numpy import linspace
from numpy import load
from numpy import loadtxt
from numpy import logspace
from numpy import longdouble as float128
from numpy import longdouble
from numpy import longlong
from numpy import ma
from numpy import mask_indices
from numpy import matrix
from numpy import matrix_transpose
from numpy import max
from numpy import may_share_memory
from numpy import mean
from numpy import median
from numpy import memmap
from numpy import meshgrid
from numpy import min
from numpy import min_scalar_type
from numpy import mintypecode
from numpy import moveaxis
from numpy import nan_to_num
from numpy import nanargmax
from numpy import nanargmin
from numpy import nancumprod
from numpy import nancumsum
from numpy import nanmax
from numpy import nanmean
from numpy import nanmedian
from numpy import nanmin
from numpy import nanpercentile
from numpy import nanprod
from numpy import nanquantile
from numpy import nanstd
from numpy import nansum
from numpy import nanvar
from numpy import ndarray
from numpy import ndenumerate
from numpy import ndim
from numpy import ndindex
from numpy import nditer
from numpy import nested_iters
from numpy import nonzero
from numpy import number
from numpy import object_
from numpy import ones
from numpy import ones_like
from numpy import outer
from numpy import packbits
from numpy import pad
from numpy import partition
from numpy import percentile
from numpy import piecewise
from numpy import place
from numpy import poly
from numpy import poly1d
from numpy import polyadd
from numpy import polyder
from numpy import polydiv
from numpy import polyfit
from numpy import polyint
from numpy import polymul
from numpy import polynomial
from numpy import polysub
from numpy import polyval
from numpy import printoptions
from numpy import prod
from numpy import promote_types
from numpy import ptp
from numpy import put
from numpy import put_along_axis
from numpy import putmask
from numpy import quantile
from numpy import random
from numpy import ravel
from numpy import ravel_multi_index
from numpy import real
from numpy import real_if_close
from numpy import rec
from numpy.rec import recarray
from numpy import record
from numpy import repeat
from numpy import require
from numpy import reshape
from numpy import resize
from numpy import result_type
from numpy import roll
from numpy import rollaxis
from numpy import roots
from numpy import rot90
from numpy import round
from numpy import row_stack
from numpy import save
from numpy import savetxt
from numpy import savez
from numpy import savez_compressed
from numpy import searchsorted
from numpy import select
from numpy import set_printoptions
from numpy import setbufsize
from numpy import setdiff1d
from numpy import seterr
from numpy import seterrcall
from numpy import setxor1d
from numpy import shape
from numpy import shares_memory
from numpy import show_config
from numpy import show_runtime
from numpy import signedinteger
from numpy import sinc
from numpy import size
from numpy import sort
from numpy import sort_complex
from numpy import split
from numpy import squeeze
from numpy import stack
from numpy import std
from numpy import str_
from numpy import strings
from numpy import sum
from numpy import swapaxes
from numpy import take
from numpy import take_along_axis
from numpy import tensordot
from numpy import testing
from numpy import tile
from numpy import timedelta64
from numpy import trace
from numpy import transpose as permute_dims
from numpy import transpose
from numpy import trapezoid
from numpy import trapz
from numpy import tri
from numpy import tril
from numpy import tril_indices
from numpy import tril_indices_from
from numpy import trim_zeros
from numpy import triu
from numpy import triu_indices
from numpy import triu_indices_from
from numpy import typename
from numpy import typing
from numpy import ufunc
from numpy import uint16 as ushort
from numpy import uint16
from numpy import uint32 as uintc
from numpy import uint32
from numpy import uint64 as ulong
from numpy import uint64
from numpy import uint64 as uintp
from numpy import uint64 as uint
from numpy import uint8 as ubyte
from numpy import uint8
from numpy import ulonglong
from numpy import union1d
from numpy import unique
from numpy import unique_all
from numpy import unique_counts
from numpy import unique_inverse
from numpy import unique_values
from numpy import unpackbits
from numpy import unravel_index
from numpy import unsignedinteger
from numpy import unstack
from numpy import unwrap
from numpy import vander
from numpy import var
from numpy import vdot
from numpy import vectorize
from numpy import void
from numpy import vsplit
from numpy import vstack
from numpy import where
from numpy import zeros
from numpy import zeros_like
from rdkit.sping import pid
__all__: list[str] = ['DrawSpiral', 'False_', 'ScalarType', 'True_', 'abs', 'absolute', 'acos', 'acosh', 'add', 'all', 'allclose', 'amax', 'amin', 'angle', 'any', 'append', 'apply_along_axis', 'apply_over_axes', 'arange', 'arccos', 'arccosh', 'arcsin', 'arcsinh', 'arctan', 'arctan2', 'arctanh', 'argmax', 'argmin', 'argpartition', 'argsort', 'argwhere', 'around', 'array', 'array2string', 'array_equal', 'array_equiv', 'array_repr', 'array_split', 'array_str', 'asanyarray', 'asarray', 'asarray_chkfinite', 'ascontiguousarray', 'asfortranarray', 'asin', 'asinh', 'asmatrix', 'astype', 'atan', 'atan2', 'atanh', 'atleast_1d', 'atleast_2d', 'atleast_3d', 'average', 'bartlett', 'base_repr', 'binary_repr', 'bincount', 'bitwise_and', 'bitwise_count', 'bitwise_invert', 'bitwise_left_shift', 'bitwise_not', 'bitwise_or', 'bitwise_right_shift', 'bitwise_xor', 'blackman', 'block', 'bmat', 'bool', 'bool_', 'broadcast', 'broadcast_arrays', 'broadcast_shapes', 'broadcast_to', 'busday_count', 'busday_offset', 'busdaycalendar', 'byte', 'bytes_', 'c_', 'can_cast', 'cbrt', 'cdouble', 'ceil', 'char', 'character', 'choose', 'clip', 'clongdouble', 'column_stack', 'common_type', 'complex128', 'complex256', 'complex64', 'complexfloating', 'compress', 'concat', 'concatenate', 'conj', 'conjugate', 'convolve', 'copy', 'copysign', 'copyto', 'core', 'corrcoef', 'correlate', 'cos', 'cosh', 'count_nonzero', 'cov', 'cross', 'csingle', 'ctypeslib', 'cumprod', 'cumsum', 'cumulative_prod', 'cumulative_sum', 'datetime64', 'datetime_as_string', 'datetime_data', 'deg2rad', 'degrees', 'delete', 'diag', 'diag_indices', 'diag_indices_from', 'diagflat', 'diagonal', 'diff', 'digitize', 'divide', 'divmod', 'dot', 'double', 'dsplit', 'dstack', 'dtype', 'dtypes', 'e', 'ediff1d', 'einsum', 'einsum_path', 'emath', 'empty', 'empty_like', 'equal', 'errstate', 'euler_gamma', 'exceptions', 'exp', 'exp2', 'expand_dims', 'expm1', 'extract', 'eye', 'f2py', 'fabs', 'fft', 'fill_diagonal', 'finfo', 'fix', 'flatiter', 'flatnonzero', 'flexible', 'flip', 'fliplr', 'flipud', 'float128', 'float16', 'float32', 'float64', 'float_power', 'floating', 'floor', 'floor_divide', 'fmax', 'fmin', 'fmod', 'format_float_positional', 'format_float_scientific', 'frexp', 'from_dlpack', 'frombuffer', 'fromfile', 'fromfunction', 'fromiter', 'frompyfunc', 'fromregex', 'fromstring', 'full', 'full_like', 'gcd', 'generic', 'genfromtxt', 'geomspace', 'get_include', 'get_printoptions', 'getbufsize', 'geterr', 'geterrcall', 'gradient', 'greater', 'greater_equal', 'half', 'hamming', 'hanning', 'heaviside', 'histogram', 'histogram2d', 'histogram_bin_edges', 'histogramdd', 'hsplit', 'hstack', 'hypot', 'i0', 'identity', 'iinfo', 'imag', 'in1d', 'index_exp', 'indices', 'inexact', 'inf', 'info', 'inner', 'insert', 'int16', 'int32', 'int64', 'int8', 'int_', 'intc', 'integer', 'interp', 'intersect1d', 'intp', 'invert', 'is_busday', 'isclose', 'iscomplex', 'iscomplexobj', 'isdtype', 'isfinite', 'isfortran', 'isin', 'isinf', 'isnan', 'isnat', 'isneginf', 'isposinf', 'isreal', 'isrealobj', 'isscalar', 'issubdtype', 'iterable', 'ix_', 'kaiser', 'kron', 'lcm', 'ldexp', 'left_shift', 'less', 'less_equal', 'lexsort', 'lib', 'linalg', 'linspace', 'little_endian', 'load', 'loadtxt', 'log', 'log10', 'log1p', 'log2', 'logaddexp', 'logaddexp2', 'logical_and', 'logical_not', 'logical_or', 'logical_xor', 'logspace', 'long', 'longdouble', 'longlong', 'ma', 'mask_indices', 'math', 'matmul', 'matrix', 'matrix_transpose', 'matvec', 'max', 'maximum', 'may_share_memory', 'mean', 'median', 'memmap', 'meshgrid', 'mgrid', 'min', 'min_scalar_type', 'minimum', 'mintypecode', 'mod', 'modf', 'moveaxis', 'multiply', 'nan', 'nan_to_num', 'nanargmax', 'nanargmin', 'nancumprod', 'nancumsum', 'nanmax', 'nanmean', 'nanmedian', 'nanmin', 'nanpercentile', 'nanprod', 'nanquantile', 'nanstd', 'nansum', 'nanvar', 'ndarray', 'ndenumerate', 'ndim', 'ndindex', 'nditer', 'negative', 'nested_iters', 'newaxis', 'nextafter', 'nonzero', 'not_equal', 'number', 'object_', 'ogrid', 'ones', 'ones_like', 'outer', 'packbits', 'pad', 'partition', 'percentile', 'permute_dims', 'pi', 'pid', 'piecewise', 'place', 'poly', 'poly1d', 'polyadd', 'polyder', 'polydiv', 'polyfit', 'polyint', 'polymul', 'polynomial', 'polysub', 'polyval', 'positive', 'pow', 'power', 'printoptions', 'prod', 'promote_types', 'ptp', 'put', 'put_along_axis', 'putmask', 'quantile', 'r_', 'rad2deg', 'radians', 'random', 'ravel', 'ravel_multi_index', 'real', 'real_if_close', 'rec', 'recarray', 'reciprocal', 'record', 'remainder', 'repeat', 'require', 'reshape', 'resize', 'result_type', 'right_shift', 'rint', 'roll', 'rollaxis', 'roots', 'rot90', 'round', 'row_stack', 's_', 'save', 'savetxt', 'savez', 'savez_compressed', 'sctypeDict', 'searchsorted', 'select', 'set_printoptions', 'setbufsize', 'setdiff1d', 'seterr', 'seterrcall', 'setxor1d', 'shape', 'shares_memory', 'short', 'show_config', 'show_runtime', 'sign', 'signbit', 'signedinteger', 'sin', 'sinc', 'single', 'sinh', 'size', 'sort', 'sort_complex', 'spacing', 'split', 'sqrt', 'square', 'squeeze', 'stack', 'std', 'str_', 'strings', 'subtract', 'sum', 'swapaxes', 'take', 'take_along_axis', 'tan', 'tanh', 'tensordot', 'test', 'testing', 'tile', 'timedelta64', 'trace', 'transpose', 'trapezoid', 'trapz', 'tri', 'tril', 'tril_indices', 'tril_indices_from', 'trim_zeros', 'triu', 'triu_indices', 'triu_indices_from', 'true_divide', 'trunc', 'typecodes', 'typename', 'typing', 'ubyte', 'ufunc', 'uint', 'uint16', 'uint32', 'uint64', 'uint8', 'uintc', 'uintp', 'ulong', 'ulonglong', 'union1d', 'unique', 'unique_all', 'unique_counts', 'unique_inverse', 'unique_values', 'unpackbits', 'unravel_index', 'unsignedinteger', 'unstack', 'unwrap', 'ushort', 'vander', 'var', 'vdot', 'vecdot', 'vecmat', 'vectorize', 'void', 'vsplit', 'vstack', 'where', 'zeros', 'zeros_like']
def DrawSpiral(canvas, startColor, endColor, startRadius, endRadius, nLoops, degsPerSlice = 70, degsPerStep = 1, startAngle = 0, centerPos = None, dir = 1):
    ...
False_: numpy.bool  # value = np.False_
ScalarType: tuple = (int, float, complex, bool, bytes, str, memoryview, numpy.bool, numpy.complex64, numpy.complex128, numpy.clongdouble, numpy.float16, numpy.float32, numpy.float64, numpy.longdouble, numpy.int8, numpy.int16, numpy.int32, numpy.longlong, numpy.int64, numpy.datetime64, numpy.timedelta64, numpy.object_, numpy.bytes_, numpy.str_, numpy.uint8, numpy.uint16, numpy.uint32, numpy.ulonglong, numpy.uint64, numpy.void)
True_: numpy.bool  # value = np.True_
__version__: str = '2.2.6'
abs: numpy.ufunc  # value = <ufunc 'absolute'>
absolute: numpy.ufunc  # value = <ufunc 'absolute'>
acos: numpy.ufunc  # value = <ufunc 'arccos'>
acosh: numpy.ufunc  # value = <ufunc 'arccosh'>
add: numpy.ufunc  # value = <ufunc 'add'>
arccos: numpy.ufunc  # value = <ufunc 'arccos'>
arccosh: numpy.ufunc  # value = <ufunc 'arccosh'>
arcsin: numpy.ufunc  # value = <ufunc 'arcsin'>
arcsinh: numpy.ufunc  # value = <ufunc 'arcsinh'>
arctan: numpy.ufunc  # value = <ufunc 'arctan'>
arctan2: numpy.ufunc  # value = <ufunc 'arctan2'>
arctanh: numpy.ufunc  # value = <ufunc 'arctanh'>
asin: numpy.ufunc  # value = <ufunc 'arcsin'>
asinh: numpy.ufunc  # value = <ufunc 'arcsinh'>
atan: numpy.ufunc  # value = <ufunc 'arctan'>
atan2: numpy.ufunc  # value = <ufunc 'arctan2'>
atanh: numpy.ufunc  # value = <ufunc 'arctanh'>
bitwise_and: numpy.ufunc  # value = <ufunc 'bitwise_and'>
bitwise_count: numpy.ufunc  # value = <ufunc 'bitwise_count'>
bitwise_invert: numpy.ufunc  # value = <ufunc 'invert'>
bitwise_left_shift: numpy.ufunc  # value = <ufunc 'left_shift'>
bitwise_not: numpy.ufunc  # value = <ufunc 'invert'>
bitwise_or: numpy.ufunc  # value = <ufunc 'bitwise_or'>
bitwise_right_shift: numpy.ufunc  # value = <ufunc 'right_shift'>
bitwise_xor: numpy.ufunc  # value = <ufunc 'bitwise_xor'>
c_: numpy.lib._index_tricks_impl.CClass  # value = <numpy.lib._index_tricks_impl.CClass object>
cbrt: numpy.ufunc  # value = <ufunc 'cbrt'>
ceil: numpy.ufunc  # value = <ufunc 'ceil'>
conj: numpy.ufunc  # value = <ufunc 'conjugate'>
conjugate: numpy.ufunc  # value = <ufunc 'conjugate'>
copysign: numpy.ufunc  # value = <ufunc 'copysign'>
cos: numpy.ufunc  # value = <ufunc 'cos'>
cosh: numpy.ufunc  # value = <ufunc 'cosh'>
deg2rad: numpy.ufunc  # value = <ufunc 'deg2rad'>
degrees: numpy.ufunc  # value = <ufunc 'degrees'>
divide: numpy.ufunc  # value = <ufunc 'divide'>
divmod: numpy.ufunc  # value = <ufunc 'divmod'>
e: float = 2.718281828459045
equal: numpy.ufunc  # value = <ufunc 'equal'>
euler_gamma: float = 0.5772156649015329
exp: numpy.ufunc  # value = <ufunc 'exp'>
exp2: numpy.ufunc  # value = <ufunc 'exp2'>
expm1: numpy.ufunc  # value = <ufunc 'expm1'>
fabs: numpy.ufunc  # value = <ufunc 'fabs'>
float_power: numpy.ufunc  # value = <ufunc 'float_power'>
floor: numpy.ufunc  # value = <ufunc 'floor'>
floor_divide: numpy.ufunc  # value = <ufunc 'floor_divide'>
fmax: numpy.ufunc  # value = <ufunc 'fmax'>
fmin: numpy.ufunc  # value = <ufunc 'fmin'>
fmod: numpy.ufunc  # value = <ufunc 'fmod'>
frexp: numpy.ufunc  # value = <ufunc 'frexp'>
gcd: numpy.ufunc  # value = <ufunc 'gcd'>
greater: numpy.ufunc  # value = <ufunc 'greater'>
greater_equal: numpy.ufunc  # value = <ufunc 'greater_equal'>
heaviside: numpy.ufunc  # value = <ufunc 'heaviside'>
hypot: numpy.ufunc  # value = <ufunc 'hypot'>
index_exp: numpy.lib._index_tricks_impl.IndexExpression  # value = <numpy.lib._index_tricks_impl.IndexExpression object>
inf: float  # value = inf
invert: numpy.ufunc  # value = <ufunc 'invert'>
isfinite: numpy.ufunc  # value = <ufunc 'isfinite'>
isinf: numpy.ufunc  # value = <ufunc 'isinf'>
isnan: numpy.ufunc  # value = <ufunc 'isnan'>
isnat: numpy.ufunc  # value = <ufunc 'isnat'>
lcm: numpy.ufunc  # value = <ufunc 'lcm'>
ldexp: numpy.ufunc  # value = <ufunc 'ldexp'>
left_shift: numpy.ufunc  # value = <ufunc 'left_shift'>
less: numpy.ufunc  # value = <ufunc 'less'>
less_equal: numpy.ufunc  # value = <ufunc 'less_equal'>
little_endian: bool = True
log: numpy.ufunc  # value = <ufunc 'log'>
log10: numpy.ufunc  # value = <ufunc 'log10'>
log1p: numpy.ufunc  # value = <ufunc 'log1p'>
log2: numpy.ufunc  # value = <ufunc 'log2'>
logaddexp: numpy.ufunc  # value = <ufunc 'logaddexp'>
logaddexp2: numpy.ufunc  # value = <ufunc 'logaddexp2'>
logical_and: numpy.ufunc  # value = <ufunc 'logical_and'>
logical_not: numpy.ufunc  # value = <ufunc 'logical_not'>
logical_or: numpy.ufunc  # value = <ufunc 'logical_or'>
logical_xor: numpy.ufunc  # value = <ufunc 'logical_xor'>
matmul: numpy.ufunc  # value = <ufunc 'matmul'>
matvec: numpy.ufunc  # value = <ufunc 'matvec'>
maximum: numpy.ufunc  # value = <ufunc 'maximum'>
mgrid: numpy.lib._index_tricks_impl.MGridClass  # value = <numpy.lib._index_tricks_impl.MGridClass object>
minimum: numpy.ufunc  # value = <ufunc 'minimum'>
mod: numpy.ufunc  # value = <ufunc 'remainder'>
modf: numpy.ufunc  # value = <ufunc 'modf'>
multiply: numpy.ufunc  # value = <ufunc 'multiply'>
nan: float  # value = nan
negative: numpy.ufunc  # value = <ufunc 'negative'>
newaxis = None
nextafter: numpy.ufunc  # value = <ufunc 'nextafter'>
not_equal: numpy.ufunc  # value = <ufunc 'not_equal'>
ogrid: numpy.lib._index_tricks_impl.OGridClass  # value = <numpy.lib._index_tricks_impl.OGridClass object>
pi: float = 3.141592653589793
positive: numpy.ufunc  # value = <ufunc 'positive'>
pow: numpy.ufunc  # value = <ufunc 'power'>
power: numpy.ufunc  # value = <ufunc 'power'>
r_: numpy.lib._index_tricks_impl.RClass  # value = <numpy.lib._index_tricks_impl.RClass object>
rad2deg: numpy.ufunc  # value = <ufunc 'rad2deg'>
radians: numpy.ufunc  # value = <ufunc 'radians'>
reciprocal: numpy.ufunc  # value = <ufunc 'reciprocal'>
remainder: numpy.ufunc  # value = <ufunc 'remainder'>
right_shift: numpy.ufunc  # value = <ufunc 'right_shift'>
rint: numpy.ufunc  # value = <ufunc 'rint'>
s_: numpy.lib._index_tricks_impl.IndexExpression  # value = <numpy.lib._index_tricks_impl.IndexExpression object>
sctypeDict: dict = {'bool': numpy.bool, 'float16': numpy.float16, 'float32': numpy.float32, 'float64': numpy.float64, 'longdouble': numpy.longdouble, 'complex64': numpy.complex64, 'complex128': numpy.complex128, 'clongdouble': numpy.clongdouble, 'bytes_': numpy.bytes_, 'str_': numpy.str_, 'void': numpy.void, 'object_': numpy.object_, 'datetime64': numpy.datetime64, 'timedelta64': numpy.timedelta64, 'int8': numpy.int8, 'byte': numpy.int8, 'uint8': numpy.uint8, 'ubyte': numpy.uint8, 'int16': numpy.int16, 'short': numpy.int16, 'uint16': numpy.uint16, 'ushort': numpy.uint16, 'int32': numpy.int32, 'intc': numpy.int32, 'uint32': numpy.uint32, 'uintc': numpy.uint32, 'int64': numpy.int64, 'long': numpy.int64, 'uint64': numpy.uint64, 'ulong': numpy.uint64, 'longlong': numpy.longlong, 'ulonglong': numpy.ulonglong, 'intp': numpy.int64, 'uintp': numpy.uint64, 'double': numpy.float64, 'cdouble': numpy.complex128, 'single': numpy.float32, 'csingle': numpy.complex64, 'half': numpy.float16, 'bool_': numpy.bool, 'int_': numpy.int64, 'uint': numpy.uint64, 'float': numpy.float64, 'complex': numpy.complex128, 'object': numpy.object_, 'bytes': numpy.bytes_, 'a': numpy.bytes_, 'int': numpy.int64, 'str': numpy.str_, 'unicode': numpy.str_, 'float128': numpy.longdouble, 'complex256': numpy.clongdouble}
sign: numpy.ufunc  # value = <ufunc 'sign'>
signbit: numpy.ufunc  # value = <ufunc 'signbit'>
sin: numpy.ufunc  # value = <ufunc 'sin'>
sinh: numpy.ufunc  # value = <ufunc 'sinh'>
spacing: numpy.ufunc  # value = <ufunc 'spacing'>
sqrt: numpy.ufunc  # value = <ufunc 'sqrt'>
square: numpy.ufunc  # value = <ufunc 'square'>
subtract: numpy.ufunc  # value = <ufunc 'subtract'>
tan: numpy.ufunc  # value = <ufunc 'tan'>
tanh: numpy.ufunc  # value = <ufunc 'tanh'>
test: numpy._pytesttester.PytestTester  # value = <numpy._pytesttester.PytestTester object>
true_divide: numpy.ufunc  # value = <ufunc 'divide'>
trunc: numpy.ufunc  # value = <ufunc 'trunc'>
typecodes: dict = {'Character': 'c', 'Integer': 'bhilqnp', 'UnsignedInteger': 'BHILQNP', 'Float': 'efdg', 'Complex': 'FDG', 'AllInteger': 'bBhHiIlLqQnNpP', 'AllFloat': 'efdgFDG', 'Datetime': 'Mm', 'All': '?bhilqnpBHILQNPefdgFDGSUVOMm'}
vecdot: numpy.ufunc  # value = <ufunc 'vecdot'>
vecmat: numpy.ufunc  # value = <ufunc 'vecmat'>
