"""
 contains code for standardization of data matrices for clustering


"""
from __future__ import annotations
from rdkit.ML.Data import Stats
__all__: list[str] = ['Stats', 'StdDev', 'methods']
def StdDev(mat):
    """
     the standard deviation classifier
    
       This uses _ML.Data.Stats.StandardizeMatrix()_ to do the work
    
      
    """
methods: list  # value = [('None', <function <lambda> at 0x7f0c2dabb2e0>, 'No Standardization'), ('Standard Deviation', StdDev, 'Use the standard deviation')]
