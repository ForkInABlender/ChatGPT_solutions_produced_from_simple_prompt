import tempfile, pathlib, random, time, resource, sys, os
BASE=pathlib.Path(__file__).parent
sys.path.insert(0,str(BASE))
from memory_manager import Memory as V28
sys.path.insert(0,str(BASE.parent / "v29_work"))
# Compare the shipped v28 lookup against the rejected sparse-directory prototype
# only when that prototype exists; this test remains a measurement record.
N=50000
with tempfile.TemporaryDirectory() as td:
    m=V28(td,limit=32)
    for i in range(N): m.put(str(i),f'unique_{i:08d} shared',working=False)
    m.checkpoint(); ix=m.idx
    rng=random.Random(123)
    qs=[f'unique_{rng.randrange(N):08d}' for _ in range(10000)] + [f'absent_{i:08d}' for i in range(10000)]
    rng.shuffle(qs)
    b=resource.getrusage(resource.RUSAGE_SELF); t=time.perf_counter(); hits=sum(ix.find(q)>=0 for q in qs); dt=time.perf_counter()-t; a=resource.getrusage(resource.RUSAGE_SELF)
    assert hits==10000
    print(f'V28 baseline high-card: tokens={ix.tc} index={os.path.getsize(pathlib.Path(td)/"semantic.idx")} lookup={len(qs)/dt:.0f}/s minflt={a.ru_minflt-b.ru_minflt} majflt={a.ru_majflt-b.ru_majflt}')
