import tempfile, pathlib, sys, shutil
v27='/mnt/data/v27_work'; v29=str(pathlib.Path(__file__).parent)
d=tempfile.mkdtemp()
try:
    sys.path.insert(0,v27)
    from memory_manager import Memory as M27
    m=M27(d,limit=2)
    for i in range(200): m.put(str(i),f'legacy{i} common',working=False)
    m.checkpoint(); m.idx.close()
    sys.path.pop(0); del sys.modules['memory_manager']
    sys.path.insert(0,v29)
    from memory_manager import Memory, Index, MAGIC29
    ix=Index(pathlib.Path(d)/'semantic.idx')
    assert ix.find('legacy123')>=0 and ix.find('missing')==-1
    ix.close()
    m=Memory(d,limit=2); m.checkpoint(); m.idx.close()
    ix=Index(pathlib.Path(d)/'semantic.idx')
    assert ix.m[:8]==MAGIC29 and ix.find('legacy123')>=0
    ix.close()
    print('V27 -> V29 migration/recheckpoint: PASS')
finally: shutil.rmtree(d,ignore_errors=True)
