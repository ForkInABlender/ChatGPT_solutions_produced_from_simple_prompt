from __future__ import annotations
import mmap, os, re, struct, heapq
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path

R=re.compile(rb"[A-Za-z0-9_]+")
H=struct.Struct("<8sIIIIQQQ")
T=struct.Struct("<IQI")
T25=struct.Struct("<IQQI")
T27=struct.Struct("<QQI")
T29=struct.Struct("<QQI")
P29=struct.Struct("<H")
E=struct.Struct("<IQQdI")
T_OLD=struct.Struct("<IQQ")
E_OLD=struct.Struct("<IQIdQI")
MAGIC=b"MMIDX27\0"
MAGIC29=b"MMIDX29\0"
MAGIC26=b"MMIDX26\0"
MAGIC25=b"MMIDX25\0"
MAGIC20=b"MMIDX20\0"
U32=struct.Struct("<I")
PFX=struct.Struct("<QQdQQ")

@dataclass(slots=True)
class Location:
    segment:int; offset:int; length:int

class Cold:
    def __init__(s,p,seg=1<<20):
        s.p=Path(p);s.p.mkdir(parents=True,exist_ok=True);s.seg=seg;s.n=s.o=0
        ns=[]
        for x in s.p.glob("cold-*.dat"):
            try: ns.append(int(x.stem.split("-")[1]))
            except: pass
        if ns:s.n=max(ns);s.o=(s.p/f"cold-{s.n:08d}.dat").stat().st_size
    def add(s,v):
        b=v.encode();z=U32.pack(len(b))+b
        if len(z)>s.seg:raise ValueError("record exceeds segment")
        if s.o+len(z)>s.seg:s.n+=1;s.o=0
        with (s.p/f"cold-{s.n:08d}.dat").open("ab") as f:f.write(z)
        l=Location(s.n,s.o+4,len(b));s.o+=len(z);return l
    def read(s,l):
        # Reuse a tiny LRU of segment handles. This removes one open/close
        # cycle per record during checkpoint without making RAM grow with
        # the number of cold segments.
        if not hasattr(s, "_fh"):
            s._fh=OrderedDict()
        f=s._fh.get(l.segment)
        if f is None:
            f=(s.p/f"cold-{l.segment:08d}.dat").open("rb")
            s._fh[l.segment]=f
            while len(s._fh)>4:
                _,old=s._fh.popitem(last=False);old.close()
        else:
            s._fh.move_to_end(l.segment)
        f.seek(l.offset);return f.read(l.length).decode()
    def close(s):
        fh=getattr(s,"_fh",None)
        if fh:
            for f in fh.values(): f.close()
            fh.clear()

class Post:
    __slots__=("m","o","n")
    def __init__(s,m,o,n):s.m,s.o,s.n=m,o,n
    def __len__(s):return s.n
    def __getitem__(s,i):
        if i<0:i+=s.n
        if not 0<=i<s.n:raise IndexError
        return U32.unpack_from(s.m,s.o+i*4)[0]
    def __iter__(s):
        for i in range(s.n):yield s[i]

class Index:
    def __init__(s,p):
        s.p=Path(p);s.m=s.f=None;s.tc=s.ec=0;s.ts=T.size;s.es=E.size;s.version_magic=MAGIC20
        if s.p.exists():
            if s.p.stat().st_size==0: return
            s.f=s.p.open("rb");s.m=mmap.mmap(s.f.fileno(),0,access=mmap.ACCESS_READ)
            magic,v,s.tc,s.ec,_,s.to,s.eo,s.po=H.unpack_from(s.m,0)
            if magic not in (b"MMIDX09\0",b"MMIDX10\0",b"MMIDX20\0",MAGIC25,MAGIC26,MAGIC,MAGIC29) or v!=1:s.close();raise ValueError("bad index")
            if magic in (b"MMIDX09\0",b"MMIDX10\0"):
                s.ts,s.es=T_OLD.size,E_OLD.size
            elif magic==MAGIC:
                s.ts,s.es=T27.size,E.size
                s.version_magic=MAGIC
            elif magic==MAGIC29:
                s.ts,s.es=T29.size,E.size
                s.version_magic=MAGIC29
            elif magic==MAGIC26:
                s.ts,s.es=T25.size,E.size
                s.version_magic=MAGIC26
            elif magic==MAGIC25:
                s.ts,s.es=T25.size,E.size
                s.version_magic=MAGIC25
            # Token-table binary search is inherently random-access.  Advise
            # the VM only for the table's mapped page range, rather than the
            # whole index: posting/entry data can retain its normal paging
            # behavior.  The hint is page-aligned and silently optional.
            try:
                if s.m is not None and hasattr(s.m, "madvise") and s.tc:
                    pg=mmap.PAGESIZE
                    start=(s.to//pg)*pg
                    end=((s.to+s.tc*s.ts+pg-1)//pg)*pg
                    end=min(end,len(s.m))
                    if end>start:
                        s.m.madvise(mmap.MADV_RANDOM,start,end-start)
                    if magic in (MAGIC,MAGIC29) and s.tc and s.po:
                        pstart=(s.po//pg)*pg
                        pwidth=4 if magic==MAGIC else 2
                        pend=((s.po+s.tc*pwidth+pg-1)//pg)*pg
                        pend=min(pend,len(s.m))
                        if pend>pstart:
                            s.m.madvise(mmap.MADV_RANDOM,pstart,pend-pstart)
            except (AttributeError,OSError,ValueError):
                pass
    def bounds(s,i):
        # The posting offset is immediately after token bytes + NUL.  Derive
        # the token end from the row itself instead of scanning the mmap for
        # a NUL byte. This preserves the on-disk format while avoiding an
        # unbounded forward scan/page fault during binary-search lookup.
        if s.version_magic in (b"MMIDX09\0",b"MMIDX10\0"):
            a,post_off,_=T_OLD.unpack_from(s.m,s.to+i*s.ts)
        elif s.version_magic==MAGIC29:
            a,post_off,_=T29.unpack_from(s.m,s.to+i*s.ts)
        elif s.version_magic==MAGIC:
            a,post_off,_=T27.unpack_from(s.m,s.to+i*s.ts)
        elif s.ts==T25.size:
            _,a,post_off,_=T25.unpack_from(s.m,s.to+i*s.ts)
        else:
            a,post_off,_=T.unpack_from(s.m,s.to+i*s.ts)
        return a,post_off-1
    def _find_row(s,t):
        lo,hi=0,s.tc
        ts=s.ts;m=s.m;to=s.to
        if s.version_magic==MAGIC29:
            qpre=int.from_bytes(t[:2].ljust(2,b"\0"),"big")
            po=s.po
            step=P29.size
            while lo<hi:
                mid=(lo+hi)//2
                pre=P29.unpack_from(m,po+mid*step)[0]
                if pre<qpre: lo=mid+1
                else: hi=mid
            first=lo
            lo,hi=first,s.tc
            while lo<hi:
                mid=(lo+hi)//2
                if P29.unpack_from(m,po+mid*step)[0]<=qpre: lo=mid+1
                else: hi=mid
            last=lo
            lo,hi=first,last
            while lo<hi:
                mid=(lo+hi)//2
                a,post_off,n=T29.unpack_from(m,to+mid*ts)
                b=post_off-1
                if m[a:b]<t: lo=mid+1
                else: hi=mid
            if lo<last:
                a,post_off,n=T29.unpack_from(m,to+lo*ts)
                if m[a:post_off-1]==t:return lo,post_off,n
            return -1,0,0
        if ts==T27.size:
            qpre=int.from_bytes(t[:4].ljust(4,b"\0"),"big")
            po=s.po
            while lo<hi:
                mid=(lo+hi)//2
                pre=U32.unpack_from(m,po+mid*4)[0]
                if pre<qpre: lo=mid+1
                else: hi=mid
            # Prefixes define a contiguous candidate range. Find both
            # bounds with binary search; never scan backward through a large
            # equal-prefix run.
            first=lo
            lo,hi=first,s.tc
            while lo<hi:
                mid=(lo+hi)//2
                if U32.unpack_from(m,po+mid*4)[0]<=qpre: lo=mid+1
                else: hi=mid
            last=lo
            lo,hi=first,last
            while lo<hi:
                mid=(lo+hi)//2
                a,post_off,n=T27.unpack_from(m,to+mid*ts)
                b=post_off-1
                if m[a:b]<t: lo=mid+1
                else: hi=mid
            if lo<last:
                a,post_off,n=T27.unpack_from(m,to+lo*ts)
                if m[a:post_off-1]==t:return lo,post_off,n
            return -1,0,0
        qpre=int.from_bytes(t[:4].ljust(4,b"\0"),"big") if ts==T25.size else None
        while lo<hi:
            mid=(lo+hi)//2
            if ts==T25.size:
                pre,a,post_off,n=T25.unpack_from(m,to+mid*ts)
                if pre<qpre:
                    lo=mid+1;continue
                if pre>qpre:
                    hi=mid;continue
            else:
                fmt=T_OLD if ts==T_OLD.size else T
                a,post_off,n=fmt.unpack_from(m,to+mid*ts)
            b=post_off-1
            if m[a:b]<t:lo=mid+1
            else:hi=mid
        if lo<s.tc:
            if ts==T25.size:
                pre,a,post_off,n=T25.unpack_from(m,to+lo*ts)
            else:
                fmt=T_OLD if ts==T_OLD.size else T
                a,post_off,n=fmt.unpack_from(m,to+lo*ts)
            if m[a:post_off-1]==t:return lo,post_off,n
        return -1,0,0
    def find(s,t):
        if s.m is None:return -1
        t=t.encode() if isinstance(t,str) else t
        return s._find_row(t)[0]
    def posts(s,t):
        if s.m is None:return ()
        t=t.encode() if isinstance(t,str) else t
        i,o,n=s._find_row(t)
        if i<0:return ()
        # o is the posting-list start returned by the successful lookup.
        return Post(s.m,o,n)
    def entry(s,i):
        if s.m is None or not 0<=i<s.ec:return None
        row=(E_OLD if s.es==E_OLD.size else E).unpack_from(s.m,s.eo+i*s.es)
        if s.es==E.size:
            rid,off,l,score,segflag=row; return (rid,off,l,score,0,segflag)
        return row
    def close(s):
        if s.m is not None:s.m.close()
        s.m=None
        if s.f:s.f.close()
        s.f=None
    @property
    def mapped(s):return s.m is not None

class Memory:
    def __init__(s,root,limit=64):
        s.root=Path(root);s.root.mkdir(parents=True,exist_ok=True)
        s.c=Cold(s.root/"cold");s.w=OrderedDict();s.limit=limit
        s.pending_path=s.root/"pending.log";s.up=OrderedDict();s.pending_seq=0;s.pending_mem_limit=max(64,limit*4)
        s._load_pending_tail()
        s.idx=Index(s.root/"semantic.idx");s.next=s.idx.ec
    def _load_pending_tail(s):
        # Recover only a bounded tail into RAM; older pending records remain on disk.
        if not s.pending_path.exists(): return
        # The log is append-only; recovery is intentionally streaming and bounded.
        with s.pending_path.open("rb") as f:
            while True:
                h=f.read(4)
                if not h: break
                n=U32.unpack(h)[0]; kb=f.read(n); body=f.read(PFX.size)
                if len(kb)!=n or len(body)!=PFX.size: raise EOFError("truncated pending log")
                off,l,score,seg,seq=struct.unpack("<QQdQQ",body)
                s.pending_seq=max(s.pending_seq,seq+1)
                s.up[kb.decode()]=(Location(seg,off,l),score,seq)
                if len(s.up)>s.pending_mem_limit:
                    s.up.popitem(last=False)

    def _append_pending(s,k,loc,score):
        seq=s.pending_seq;s.pending_seq+=1
        s.up[k]=(loc,score,seq);s.up.move_to_end(k)
        while len(s.up)>s.pending_mem_limit:
            oldk,(oloc,oscore,oseq)=s.up.popitem(last=False)
            with s.pending_path.open("ab") as f:
                kb=oldk.encode();f.write(U32.pack(len(kb)));f.write(kb);f.write(PFX.pack(oloc.offset,oloc.length,oscore,oloc.segment,oseq))

    def _iter_pending(s):
        if s.pending_path.exists():
            with s.pending_path.open("rb") as f:
                while True:
                    h=f.read(4)
                    if not h: break
                    n=U32.unpack(h)[0];kb=f.read(n);body=f.read(PFX.size)
                    if len(kb)!=n or len(body)!=PFX.size: raise EOFError("truncated pending log")
                    off,l,score,seg,seq=struct.unpack("<QQdQQ",body)
                    yield kb,Location(seg,off,l),score,seq
        for k,(loc,score,seq) in s.up.items():
            yield k.encode(),loc,score,seq

    def toks(s,x):
        # Byte-oriented tokenization avoids allocating an intermediate list of
        # Python unicode strings.  The returned set is bounded by the number
        # of distinct tokens in one record.
        b=x.encode() if isinstance(x,str) else x
        return set(m.group(0).lower() for m in R.finditer(b))
    def toks_sorted_bytes(s,x):
        b=x.encode() if isinstance(x,str) else x
        return sorted(set(m.group(0).lower() for m in R.finditer(b)))
    def put(s,k,v,score=0,working=True):
        if not working:s._append_pending(k,s.c.add(v),score);return
        s.w[k]=v;s.w.move_to_end(k)
        while len(s.w)>s.limit:
            k,v=s.w.popitem(last=False);s._append_pending(k,s.c.add(v),score)
    def has(s,p,r):
        lo,hi=0,len(p)
        while lo<hi:
            m=(lo+hi)//2
            if p[m]<r:lo=m+1
            else:hi=m
        return lo<len(p) and p[lo]==r
    def search(s,q,limit=20):
        q=list(s.toks(q));out=[]
        if not q:return out
        for k,v in s.w.items():
            tv=s.toks(v)
            if all(x in tv for x in q):out.append((k,v,1.0))
            if len(out)>=limit:return out
        if not s.idx.mapped:return out
        ps=[s.idx.posts(x) for x in q]
        if any(not len(p) for p in ps):return out
        ps.sort(key=len)
        for r in ps[0]:
            if all(s.has(p,r) for p in ps[1:]):
                e=s.idx.entry(r)
                if e is None: continue
                out.append((f"record:{r}",s.c.read(Location(e[5]>>1,e[1],e[2])),e[3]))
                if len(out)>=limit:break
        return out

    def checkpoint(s):
        """Compact all pending records into the immutable mmap index.

        v17 writes the new index in one forward pass after the external sorts:
        the entry table is emitted first, then fixed token-table slots are
        reserved and patched in-place as token postings are streamed.  This
        removes the token-meta/posting-pool/final-assembly disk passes used by
        v16 while keeping merge fan-in bounded.
        """
        FANIN=64; CHUNK=128
        tmp=s.root/"semantic.idx.tmp"; final=s.root/"semantic.idx"
        entries_tmp=s.root/"pending-entry-table.tmp"
        table_tmp=s.root/"token-table.tmp"; prefix_tmp=s.root/"token-prefix.tmp"
        keyruns=[]; runs=[]
        try:
            class Run:
                __slots__=("f",)
                def __init__(r,path): r.f=path.open("rb", buffering=8<<10)
                def next(r):
                    h=r.f.read(4)
                    if not h:return None
                    n=U32.unpack(h)[0];k=r.f.read(n);b=r.f.read(PFX.size)
                    if len(k)!=n or len(b)!=PFX.size:raise EOFError("truncated pending run")
                    off,l,score,seg,seq=struct.unpack("<QQdQQ",b)
                    return k,(Location(seg,off,l),score,seq)
                def close(r):r.f.close()

            def merge(paths,outpath):
                opened=[Run(p) for p in paths];h=[]
                try:
                    for i,rn in enumerate(opened):
                        x=rn.next()
                        if x:h.append((x[0],x[1][2],i,x[1]))
                    heapq.heapify(h)
                    with outpath.open("wb",buffering=1<<20) as o:
                        try:
                            if hasattr(os, "posix_fadvise"):
                                os.posix_fadvise(o.fileno(), 0, 0, os.POSIX_FADV_SEQUENTIAL)
                        except OSError:
                            pass
                        while h:
                            k,seq,i,val=heapq.heappop(h);loc,score,ss=val
                            o.write(U32.pack(len(k)));o.write(k);o.write(PFX.pack(loc.offset,loc.length,score,loc.segment,ss))
                            x=opened[i].next()
                            if x:heapq.heappush(h,(x[0],x[1][2],i,x[1]))
                finally:
                    for r in opened:r.close()

            # 1. External-sort pending records by key/sequence.
            buf=[];ri=0
            for kb,loc,score,seq in s._iter_pending():
                buf.append((kb,seq,loc,score))
                if len(buf)>=CHUNK:
                    buf.sort(key=lambda x:(x[0],x[1]));rp=s.root/f"pkey-{ri:06d}.run"
                    with rp.open("wb",buffering=1<<20) as o:
                        for k,ss,l,sc in buf:
                            o.write(U32.pack(len(k)));o.write(k);o.write(PFX.pack(l.offset,l.length,sc,l.segment,ss))
                    keyruns.append(rp);buf.clear();ri+=1
            if buf:
                buf.sort(key=lambda x:(x[0],x[1]));rp=s.root/f"pkey-{ri:06d}.run"
                with rp.open("wb",buffering=1<<20) as o:
                    for k,ss,l,sc in buf:
                        o.write(U32.pack(len(k)));o.write(k);o.write(PFX.pack(l.offset,l.length,sc,l.segment,ss))
                keyruns.append(rp);buf.clear()
            passno=0
            while len(keyruns)>FANIN:
                new=[]
                for base in range(0,len(keyruns),FANIN):
                    group=keyruns[base:base+FANIN];rp=s.root/f"pmerge-{passno:04d}-{base:06d}.run"
                    merge(group,rp);new.append(rp)
                    for q in group:q.unlink(missing_ok=True)
                    passno+=1
                keyruns=new

            # 2. Prepare the new index temp.  We deliberately put entries
            # before token table/data so token-table rows can be patched after
            # their offsets are known, avoiding a second metadata file/pass.
            old_ec=s.idx.ec if s.idx.mapped else 0
            s._old_index_for_v17=s.idx
            with tmp.open("wb",buffering=1<<20) as out:
                out.write(b"\0"*H.size)
                try:
                    if hasattr(os, "posix_fadvise"):
                        os.posix_fadvise(out.fileno(), 0, 0, os.POSIX_FADV_SEQUENTIAL)
                except OSError:
                    pass
                if s.idx.mapped and old_ec:
                    if s.idx.es==E.size:
                        pos=s.idx.eo;rem=old_ec*E.size
                        while rem:
                            n=min(1<<20,rem);out.write(s.idx.m[pos:pos+n]);pos+=n;rem-=n
                    else:
                        for ei in range(old_ec):
                            rid,off,l,score,hv,segflag=E_OLD.unpack_from(s.idx.m,s.idx.eo+ei*E_OLD.size)
                            out.write(E.pack(rid,off,l,score,segflag))

                opened=[Run(p) for p in keyruns];h=[];rid=s.next;new_ec=0
                try:
                    for i,rn in enumerate(opened):
                        x=rn.next()
                        if x:h.append((x[0],x[1][2],i,x[1]))
                    heapq.heapify(h)
                    while h:
                        k,seq,i,chosen=heapq.heappop(h); sources=[i]
                        while h and h[0][0]==k:
                            _,_,src,val=heapq.heappop(h);chosen=val;sources.append(src)
                        loc,score,_=chosen
                        out.write(E.pack(rid,loc.offset,loc.length,score,loc.segment<<1))
                        new_ec+=1;rid+=1
                        for src in sources:
                            x=opened[src].next()
                            if x:heapq.heappush(h,(x[0],x[1][2],src,x[1]))
                finally:
                    for r in opened:r.close()

                ec=old_ec+new_ec
                # Old mmap is no longer required after entries are copied.
                # Keep the old index mapped until old postings have been merged.

                # 3. Merge token runs into a single forward-only token stream,
                #    with bounded fan-in.
                def merge_token_runs(paths,outpath):
                    class TRN:
                        __slots__=("f",)
                        def __init__(r,path):r.f=path.open("rb",buffering=8<<10)
                        def nxt(r):
                            h=r.f.read(4)
                            if not h:return None
                            n=U32.unpack(h)[0];t=r.f.read(n);b=r.f.read(4)
                            if len(t)!=n or len(b)!=4:raise EOFError("truncated token run")
                            return t,U32.unpack(b)[0]
                        def close(r):r.f.close()
                    rs=[TRN(p) for p in paths];hh=[]
                    try:
                        for i,rn in enumerate(rs):
                            x=rn.nxt()
                            if x:hh.append((x[0],x[1],i))
                        heapq.heapify(hh)
                        with outpath.open("wb",buffering=1<<20) as o:
                            while hh:
                                t,r,i=heapq.heappop(hh);o.write(U32.pack(len(t)));o.write(t);o.write(U32.pack(r))
                                x=rs[i].nxt()
                                if x:heapq.heappush(hh,(x[0],x[1],i))
                    finally:
                        for rn in rs:rn.close()

                # Generate token runs from the newly selected records.
                # Re-read the appended entry rows sequentially, avoiding any
                # Python list of selected records.
                batch=[]; token_occurrences=0; entry_pos=H.size+old_ec*E.size
                # Flush the output stream before a second descriptor reads the
                # newly appended entry rows.
                out.flush()
                # The new rows are already in `tmp`; read them by fixed width.
                with tmp.open("rb",buffering=8<<10) as ef:
                    ef.seek(entry_pos)
                    for _ in range(new_ec):
                        row=ef.read(E.size)
                        rid2,off,l,score,segflag=E.unpack(row)
                        loc=Location(segflag>>1,off,l)
                        toks=s.toks_sorted_bytes(s.c.read(loc))
                        token_occurrences += len(toks)
                        batch.extend((t,rid2) for t in toks)
                        if len(batch)>=CHUNK:
                            rp=s.root/f"tok-{len(runs):06d}.run";batch.sort()
                            with rp.open("wb",buffering=1<<20) as o:
                                for t,r in batch:o.write(U32.pack(len(t)));o.write(t);o.write(U32.pack(r))
                            runs.append(rp);batch.clear()
                if batch:
                    batch.sort();rp=s.root/f"tok-{len(runs):06d}.run"
                    with rp.open("wb",buffering=1<<20) as o:
                        for t,r in batch:o.write(U32.pack(len(t)));o.write(t);o.write(U32.pack(r))
                    runs.append(rp);batch.clear()

                passno=0
                while len(runs)>FANIN:
                    merged=[]
                    for base in range(0,len(runs),FANIN):
                        group=runs[base:base+FANIN];rp=s.root/f"tmerge-{passno:04d}-{base:06d}.run"
                        merge_token_runs(group,rp);merged.append(rp)
                        for q in group:q.unlink(missing_ok=True)
                        passno+=1
                    runs=merged

                # 4. Stream the merged token/posting data directly into the
                # index and write fixed-width token rows sequentially to a
                # compact temporary table.  The table is appended after the
                # payload, so no distinct-token counting pass or random row
                # patching is required.
                oldidx=s._old_index_for_v17
                token_table_start=out.tell()  # payload starts immediately here
                table_count=0

                class TR:
                    __slots__=("f",)
                    def __init__(r,p): r.f=p.open("rb",buffering=8<<10)
                    def nxt(r):
                        h=r.f.read(4)
                        if not h:return None
                        n=U32.unpack(h)[0];t=r.f.read(n);b=r.f.read(4)
                        if len(t)!=n or len(b)!=4:raise EOFError("truncated token run")
                        return t,U32.unpack(b)[0]
                    def close(r):r.f.close()

                trs=[TR(q) for q in runs];hh=[]
                try:
                    for i,rn in enumerate(trs):
                        x=rn.nxt()
                        if x:hh.append((x[0],x[1],i))
                    heapq.heapify(hh)
                    old_i=old_pi=0;old_post=None;old_tok=None
                    def oldnext():
                        nonlocal old_i,old_pi,old_post,old_tok
                        while old_i<oldidx.tc:
                            if old_post is None:
                                # The old index is already sorted.  Consume its
                                # token row directly instead of calling posts(),
                                # which would perform a second binary search for
                                # every token during checkpoint.
                                base=oldidx.to+old_i*oldidx.ts
                                if oldidx.version_magic in (b"MMIDX09\0",b"MMIDX10\0"):
                                    a,post_off,n=T_OLD.unpack_from(oldidx.m,base)
                                elif oldidx.version_magic==MAGIC29:
                                    a,post_off,n=T29.unpack_from(oldidx.m,base)
                                elif oldidx.version_magic==MAGIC:
                                    a,post_off,n=T27.unpack_from(oldidx.m,base)
                                elif oldidx.ts==T25.size:
                                    _,a,post_off,n=T25.unpack_from(oldidx.m,base)
                                else:
                                    a,post_off,n=T.unpack_from(oldidx.m,base)
                                old_tok=bytes(oldidx.m[a:post_off-1])
                                old_post=Post(oldidx.m,post_off,n)
                                old_pi=0
                            if old_pi<len(old_post):
                                r=old_post[old_pi];old_pi+=1;return old_tok,r
                            old_i+=1;old_post=None
                        return None
                    x=oldnext()
                    if x:hh.append((x[0],x[1],-1))
                    heapq.heapify(hh)
                    with table_tmp.open("wb",buffering=1<<20) as table, prefix_tmp.open("wb",buffering=1<<20) as pref:
                        last=None;post_start=0;post_count=0;token_start=0
                        while hh:
                            tok,r,src=heapq.heappop(hh)
                            if last is None:
                                last=tok;token_start=out.tell();out.write(tok);out.write(b"\0")
                                post_start=out.tell();post_count=0
                            elif tok!=last:
                                pref.write(P29.pack(int.from_bytes(last[:2].ljust(2,b"\0"),"big")));table.write(T29.pack(token_start,post_start,post_count));table_count+=1
                                last=tok;token_start=out.tell();out.write(tok);out.write(b"\0")
                                post_start=out.tell();post_count=0
                            out.write(U32.pack(r));post_count+=1
                            y=oldnext() if src==-1 else trs[src].nxt()
                            if y:heapq.heappush(hh,(y[0],y[1],src))
                        if last is not None:
                            pref.write(P29.pack(int.from_bytes(last[:2].ljust(2,b"\0"),"big")));table.write(T29.pack(token_start,post_start,post_count));table_count+=1
                        table.flush();pref.flush();os.fsync(table.fileno());os.fsync(pref.fileno())
                finally:
                    for f in trs:f.close()

                # The old index has now been consumed completely.  Tell the
                # kernel that its mapped pages are no longer useful before the
                # new index is committed.  This is a Linux/Unix VM hint only;
                # the code remains portable when mmap.madvise is unavailable.
                try:
                    if oldidx.m is not None and hasattr(oldidx.m, "madvise"):
                        oldidx.m.madvise(mmap.MADV_DONTNEED)
                except (AttributeError, OSError, ValueError):
                    pass

                # The token table is appended sequentially after the payload.
                # Index lookups use the header's `to` offset, so its location
                # no longer needs to be reserved before token streaming.
                token_table_start=out.tell()
                with table_tmp.open("rb",buffering=1<<20) as table:
                    while True:
                        chunk=table.read(1<<20)
                        if not chunk:break
                        out.write(chunk)
                prefix_start=out.tell()
                with prefix_tmp.open("rb",buffering=1<<20) as pref:
                    while True:
                        chunk=pref.read(1<<20)
                        if not chunk:break
                        out.write(chunk)
                out.seek(0)
                out.write(H.pack(MAGIC29,1,table_count,ec,0,token_table_start,H.size,prefix_start))
                out.flush();os.fsync(out.fileno())
            os.replace(tmp,final)
            s.idx=Index(final);s.next=s.idx.ec;s.up.clear()
            with s.pending_path.open("wb"):pass
        finally:
            # `_old_index_for_v17` is only an internal lifetime anchor.
            old=s.__dict__.pop("_old_index_for_v17",None)
            if old is not None: old.close()
            for q in list(s.root.glob("pkey-*.run"))+list(s.root.glob("pmerge-*.run"))+list(s.root.glob("tok-*.run"))+list(s.root.glob("tmerge-*.run"))+[tmp,entries_tmp,table_tmp,prefix_tmp]:
                q.unlink(missing_ok=True)
