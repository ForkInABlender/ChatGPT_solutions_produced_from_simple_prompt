import tempfile, pathlib, sys, shutil
v26='/mnt/data/v26_work'; v27='/mnt/data/v27_work'
d=tempfile.mkdtemp()
try:
    sys.path.insert(0,v26)
    from memory_manager import Memory as M26
    m=M26(d,limit=2); m.put('a','alpha common',working=False); m.put('b','beta common',working=False); m.checkpoint(); m.idx.close()
    sys.path.pop(0); del sys.modules['memory_manager']
    sys.path.insert(0,v27)
    from memory_manager import Index
    ix=Index(pathlib.Path(d)/'semantic.idx')
    assert ix.find('alpha')>=0 and ix.find('beta')>=0 and ix.find('missing')==-1
    ix.close()
    print('V26 -> V27 compatibility: PASS')
finally: shutil.rmtree(d,ignore_errors=True)
