import tempfile, pathlib, time, random, sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from memory_manager import Memory, Index
with tempfile.TemporaryDirectory() as td:
    m=Memory(td,limit=8)
    for i in range(20000): m.put(str(i), f'word{i} common alpha{i%997}', working=False)
    m.checkpoint(); ix=m.idx
    hits=[f'alpha{i%997}' for i in range(10000)]
    misses=[f'absent{i}' for i in range(10000)]
    q=hits+misses; random.Random(7).shuffle(q)
    t=time.perf_counter(); c=0
    for x in q:
        if ix.find(x)>=0:c+=1
    dt=time.perf_counter()-t
    assert c==10000
    print(f'V27 lookup: {len(q)} queries, hits={c}, {len(q)/dt:.0f} lookups/s, {dt:.4f}s')
