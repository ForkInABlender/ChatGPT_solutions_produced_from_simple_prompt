# Three-Tier Memory Manager v28

v28 keeps the MMIDX27 format and optimizes the prefix lookup algorithm without adding persistent RAM state.

## Change

MMIDX27 stores a dense 4-byte lexical prefix array. The previous lookup found the lower prefix bound and then searched the entire token population while repeatedly checking prefixes. v28 computes **both prefix bounds with binary search** and performs the exact token-byte search only inside that bounded range.

This changes the lookup work from approximately `O(log N)` prefix filtering plus another `O(log N)` search over the full table to `O(log N + log R)`, where `R` is the number of tokens sharing the queried four-byte prefix. The common case of a small prefix range therefore avoids unnecessary token-table probes.

No on-disk format change. MMIDX27 remains the output format, and the existing MMIDX09/MMIDX10/MMIDX20/MMIDX25/MMIDX26 readers remain intact.

## Verification

- `py_compile`: PASS
- v27 functional regression: PASS
- v26 -> v27 compatibility: PASS
- prefix-range regression: PASS
- 20K randomized hit/miss lookup: PASS
- 100K-record stress: PASS

Observed 100K stress in the build environment:

- 100,000 records
- 1,350 distinct tokens
- 4,844,015-byte index
- `tracemalloc` peak: 4,264,281 bytes
- checkpoint: 18.432 s

A same-dataset 20K lookup comparison was also run against the v27 implementation. Results varied within normal interpreter noise (about 164k lookups/s for v27 versus about 163k lookups/s for v28), so v28 is not claimed to be faster on that small benchmark. Its benefit is specifically reduced prefix-search work when the token population is large and prefixes are selective.
