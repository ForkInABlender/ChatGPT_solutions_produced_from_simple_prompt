import subprocess,sys,os,textwrap,tempfile
script=r'''
import tempfile,random,time,os,sys
sys.path.insert(0, MODULEDIR)
from memory_manager import Memory,Index
N=50000
with tempfile.TemporaryDirectory() as d:
 m=Memory(d,limit=64)
 words=[f"word{i:06d}_x" for i in range(N)]
 for i,w in enumerate(words):m.put(str(i),w,working=False)
 t=time.perf_counter();m.checkpoint();ct=time.perf_counter()-t
 ix=Index(os.path.join(d,'semantic.idx'))
 qs=[words[random.randrange(N)] for _ in range(10000)]+[f"miss{i:06d}_z" for i in range(10000)];random.seed(7);random.shuffle(qs)
 t=time.perf_counter();h=sum(ix.find(q)>=0 for q in qs);et=time.perf_counter()-t
 print(N,ix.tc,os.path.getsize(os.path.join(d,'semantic.idx')),f'{ct:.3f}',f'{len(qs)/et:.0f}',h)
'''
for v in ['v28_work','v29_work']:
 s=script.replace('MODULEDIR',repr('/mnt/data/'+v))
 subprocess.run([sys.executable,'-c',s],check=True)
