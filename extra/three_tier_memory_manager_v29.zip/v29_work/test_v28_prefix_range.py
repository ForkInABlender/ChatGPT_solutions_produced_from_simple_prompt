import tempfile, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from memory_manager import Memory

with tempfile.TemporaryDirectory() as td:
    m=Memory(td, limit=8)
    for i in range(5000):
        m.put(str(i), f'zz{i:05d} aa{i%97}', working=False)
    m.checkpoint()
    ix=m.idx
    for q in ('zz00000','zz01234','zz04999','aa1','missing-token'):
        got=ix.find(q)
        if q=='missing-token': assert got == -1
        else: assert got >= 0
print('V28 prefix-range lookup: PASS')
