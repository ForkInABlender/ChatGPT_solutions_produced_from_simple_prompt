import tempfile, pathlib, time, tracemalloc, os, sys, random
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from memory_manager import Memory, Index
N=100000
with tempfile.TemporaryDirectory() as td:
    m=Memory(td,limit=64)
    for i in range(N):
        m.put(f'k{i}', f'alpha{i%997} beta{i%251} gamma{i%101} common', working=False)
    tracemalloc.start(); t=time.perf_counter(); m.checkpoint(); elapsed=time.perf_counter()-t
    peak=tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    size=os.path.getsize(pathlib.Path(td)/'semantic.idx')
    assert m.idx.find('alpha0')>=0 and m.idx.find('common')>=0 and m.idx.find('not-present')==-1
    assert m.idx.tc>=1000
    print(f'V27 100K: tokens={m.idx.tc} index={size} peak={peak} checkpoint={elapsed:.3f}s')
