import tempfile, pathlib, sys, os, time, tracemalloc
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from memory_manager import Memory
with tempfile.TemporaryDirectory() as td:
    m=Memory(td,limit=64)
    for i in range(100000): m.put(str(i),f'word{i:06d}_x',working=False)
    tracemalloc.start(); t=time.perf_counter(); m.checkpoint(); dt=time.perf_counter()-t
    cur,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    size=os.path.getsize(os.path.join(td,'semantic.idx'))
    assert m.idx.tc==100000 and m.idx.find('word099999_x')>=0
    print(f'V29 100K: tokens={m.idx.tc} index={size} peak={peak} checkpoint={dt:.3f}s')
