# Three-Tier Memory Manager v29

v29 continues the immutable semantic-index optimization from v28.

## Change

MMIDX29 retains the split prefix-array design but reduces the prefix discriminator from 32 bits to 16 bits:

- token metadata: 20 bytes/token (`<QQI`)
- prefix discriminator: 2 bytes/token (`<H`)
- total token-index metadata: 22 bytes/token

The prefix is the first two token bytes, preserving lexical ordering. Lookup uses lower/upper bounds on the 16-bit prefix and then exact token-byte comparison inside that candidate range.

The existing MMIDX09/MMIDX10/MMIDX20/MMIDX25/MMIDX26/MMIDX27 formats remain readable. New checkpoints emit MMIDX29.

## Verification

Tests executed successfully:

- Python `py_compile`
- v29 format and lookup regression
- v27 -> v29 migration and re-checkpoint
- 20K high-cardinality lookup benchmark
- 50K v28/v29 identical-workload comparison
- 100K checkpoint stress

Representative results from this environment:

- 50K high-cardinality: v28 128,858 lookups/s; v29 138,113 lookups/s
- 50K index: v28 3,650,048 bytes; v29 3,550,048 bytes
- 100K: 100,000 tokens, 7,100,048-byte index, 4,333,112-byte tracemalloc peak, 14.579 s checkpoint

The benchmark is evidence for a smaller index and an improvement on that particular workload, not a universal performance guarantee.
