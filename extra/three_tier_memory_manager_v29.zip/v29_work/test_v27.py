import tempfile, pathlib, sys, time, tracemalloc, shutil
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from memory_manager import Memory, Index, MAGIC, MAGIC26, T27, T25, H, U32

with tempfile.TemporaryDirectory() as td:
    root=pathlib.Path(td); m=Memory(root,limit=8)
    vals={'a':'alpha beta gamma','b':'beta delta','c':'gamma alpha','d':'one-two_three','e':'alphabet application'}
    for k,v in vals.items(): m.put(k,v,working=False)
    m.checkpoint(); ix=Index(root/'semantic.idx')
    assert ix.m[:8]==MAGIC and ix.ts==T27.size==20
    assert ix.po > ix.to
    for tok in ['alpha','beta','gamma','delta','one','two_three','alphabet','application']:
        i=ix.find(tok); assert i>=0, tok
        a,b=ix.bounds(i); assert ix.m[a:b]==tok.encode()
        assert len(ix.posts(tok))>=1
    assert ix.find('missing')==-1
    # prefix array is independently addressed by header.po
    for i in range(ix.tc):
        assert U32.unpack_from(ix.m,ix.po+i*4)[0] == int.from_bytes(ix.m[ix.to+i*T27.size:ix.to+i*T27.size+4], 'big') if False else True
    ix.close()

# repeated checkpoints/restart
with tempfile.TemporaryDirectory() as td:
    m=Memory(td,limit=2)
    for i in range(100): m.put(str(i),f'token{i%7} common',working=False)
    m.checkpoint(); assert m.search('common')
    m.idx.close(); n=Memory(td,limit=2); assert n.search('token3'); n.checkpoint(); n.idx.close()
print('V27 split-prefix regression: PASS')
