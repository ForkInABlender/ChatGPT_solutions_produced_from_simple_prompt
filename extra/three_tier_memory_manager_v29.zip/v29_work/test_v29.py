import tempfile, random, os, struct, sys
sys.path.insert(0, os.path.dirname(__file__))
from memory_manager import Memory, Index, MAGIC29, T29, P29

with tempfile.TemporaryDirectory() as d:
    m=Memory(d, limit=16)
    words=[f"tok{i:05d}" for i in range(5000)]
    for i,w in enumerate(words):
        m.put(f"k{i}", w, score=i/100.0, working=False)
    m.checkpoint()
    ix=Index(os.path.join(d,'semantic.idx'))
    assert ix.m[:8]==MAGIC29
    assert ix.ts==T29.size==20
    assert ix.tc==5000
    assert os.path.getsize(os.path.join(d,'semantic.idx')) < 5000*30 + 200000
    for w in random.sample(words, 500): assert ix.find(w)==ix.find(w)
    assert ix.find('does_not_exist') == -1
    assert len(ix.posts('tok00001')) == 1
    ix.close()
print('v29 format/lookup: PASS')
