import tempfile, os, random, time, sys
sys.path.insert(0, os.path.dirname(__file__))
from memory_manager import Memory, Index
N=20000
with tempfile.TemporaryDirectory() as d:
    m=Memory(d,limit=64)
    words=[f"word{i:06d}_x" for i in range(N)]
    for i,w in enumerate(words): m.put(f"k{i}",w,working=False)
    t=time.perf_counter();m.checkpoint(); ct=time.perf_counter()-t
    ix=Index(os.path.join(d,'semantic.idx'))
    qs=[words[random.randrange(N)] for _ in range(10000)] + [f"miss{i:06d}_z" for i in range(10000)]
    random.shuffle(qs)
    t=time.perf_counter();hits=sum(ix.find(q)>=0 for q in qs); et=time.perf_counter()-t
    print(f'N={N} tokens={ix.tc} index={os.path.getsize(os.path.join(d,"semantic.idx"))} checkpoint={ct:.3f}s lookup={len(qs)/et:.0f}/s hits={hits}')
    ix.close()
